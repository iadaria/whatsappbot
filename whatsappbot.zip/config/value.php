<?php
    return [
        'chatapiurl' => env('CHAT_API_URL', null),
        'chatapitoken' => env('CHAT_API_TOKEN', null),
        'chatid' => env('CHATID', null),
        'testsendtime' => env('TEST_SEND_TIME', 0),
        'testreceivedtime' => env('TEST_RECEIVED_TIME', 0),
    ];