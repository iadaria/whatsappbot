<h1>Hellow</h1>
<p>{{ var_dump($input) }}</p>